# Git Browser for Kodi

The git browser for kodi has been updated to be Python 3 compatible with all the crap removed.<br />
<br />
*Note: this still may have issues*<br />
To Do:<br />
- Go through properly to make sure there are no errors
